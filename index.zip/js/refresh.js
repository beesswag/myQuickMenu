function refreshIframe() {
    var ifr = document.getElementsByName('frame')[0];
    ifr.src = ifr.src;
}